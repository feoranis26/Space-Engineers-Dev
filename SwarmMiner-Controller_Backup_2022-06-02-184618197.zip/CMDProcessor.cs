﻿using Sandbox.Game.EntityComponents;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using VRage;
using VRage.Collections;
using VRage.Game;
using VRage.Game.Components;
using VRage.Game.GUI.TextPanel;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ModAPI.Ingame.Utilities;
using VRage.Game.ObjectBuilders.Definitions;
using VRageMath;

namespace IngameScript
{
    partial class Program
    {
        public class CMDProcessor
        {

            const string SETNAME_ARGUMENT = "!setname";
            const string MOVE_MINER_TO_ARGUMENT = "%move";

            SwarmController ctl;
            MinerComms comms;

            public void Init(MinerComms c, SwarmController ct)
            {
                comms = c;
                ctl = ct;
            }
            public void Process(string arg)
            {
                comms.program.Echo(arg);
                string[] split = arg.Split(' ');
                if(split.Length == 0) { return; }
                switch (split[0])
                {
                    case SETNAME_ARGUMENT:
                        if(split.Length < 2) { return; }
                        comms.SystemName = split[1];
                        break;
                    case MOVE_MINER_TO_ARGUMENT:
                        if (split.Length < 3) { return; }
                        ctl.MoveMinerToWaypoint(ctl.Miners[int.Parse(split[1])], int.Parse(split[2]));
                        break;

                    case "%mstate":
                        if (split.Length < 3) { return; }
                        ctl.SetState(ctl.Miners[int.Parse(split[1])], (MinerState)int.Parse(split[2]));
                        break;
                    case "%pstate":
                        if (split.Length < 3) { return; }
                        ctl.SetState(ctl.Miners[int.Parse(split[1])], (MinerPositionState)int.Parse(split[2]));
                        break;
                    case "%astate":
                        if (split.Length < 3) { return; }
                        ctl.SetState(ctl.Miners[int.Parse(split[1])], (MinerActivityState)int.Parse(split[2]));
                        break;

                    case "%state":
                        if (split.Length < 2) { return; }
                        Job.State = (SystemState)int.Parse(split[1]);
                        break;
                    case "%RESET":
                        ctl.Load("*0");
                        comms.program.Storage = "*0";
                        break;
                }
            }
        }
    }
}
