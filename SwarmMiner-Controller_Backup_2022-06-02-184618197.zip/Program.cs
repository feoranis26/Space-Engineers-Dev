﻿using Sandbox.Game.EntityComponents;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using VRage;
using VRage.Collections;
using VRage.Game;
using VRage.Game.Components;
using VRage.Game.GUI.TextPanel;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ModAPI.Ingame.Utilities;
using VRage.Game.ObjectBuilders.Definitions;
using VRageMath;

namespace IngameScript
{
    partial class Program : MyGridProgram
    {
        //TODO Refactor

        //TODO GUI Display modules
        //TODO Main control logic independent of single miners
        //TODO Job state control

        //TODO Haulers to return ore into mothership

        MinerComms comms = new MinerComms();
        SwarmController controller = new SwarmController();
        CMDProcessor cmdProcessor = new CMDProcessor();
        Navigation nav = new Navigation();
        GridInteractions gridInteractions = new GridInteractions();
        public Program()
        {
            gridInteractions.Init(this);
            gridInteractions.Prefix = "[SWM]";

            nav.Init(this, gridInteractions);
            comms.Init(this, IGC, controller);
            controller.Init(comms, nav, this);
            cmdProcessor.Init(comms, controller);

            controller.Load(Storage);

            Runtime.UpdateFrequency = UpdateFrequency.Update1 | UpdateFrequency.Update10 | UpdateFrequency.Update100;
        }

        public void Save()
        {
            Storage = "";
            controller.Save();
        }

        public void Main(string argument, UpdateType updateSource)
        {
            Echo("Connected miners: " + controller.ConnectedMiners);
            Echo("Registered miners: " + controller.Miners.Count);
            Echo("Busy miners: " + controller.BusyMiners);

            foreach (Miner miner in controller.Miners)
                Echo(miner.EntityId.ToString());

            Echo("HB:");
            foreach (HeartbeatClientData data in comms.hb.Clients)
                Echo(data.id.ToString());

            Echo("State: " + Job.State);

            controller.Tick(updateSource);
            comms.Tick(updateSource);

            if ((updateSource & UpdateType.Update100) > 0)
                nav.Tick();

            if(argument != "")
            {
                cmdProcessor.Process(argument);
            }  
        }
    }
}
