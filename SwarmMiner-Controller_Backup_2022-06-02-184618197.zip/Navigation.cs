﻿using Sandbox.Game.EntityComponents;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using VRage;
using VRage.Collections;
using VRage.Game;
using VRage.Game.Components;
using VRage.Game.GUI.TextPanel;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ModAPI.Ingame.Utilities;
using VRage.Game.ObjectBuilders.Definitions;
using VRageMath;

namespace IngameScript
{
    partial class Program
    {
        public class Navigation
        {

            public List<PathNode> Nodes = new List<PathNode>();
            public List<int> HangarNodes = new List<int>();
            public int HangarEntrance;
            public int Jobsite;


            public List<int> HangarDocks = new List<int>();
            public List<int> Docks = new List<int>();


            public Matrix WorldMatrix;

            GridInteractions gridInteractions;

            Program prog;

            public void Init(Program p, GridInteractions g)
            {
                gridInteractions = g;

                WorldMatrix = gridInteractions.GetBlockWithTag<IMyRemoteControl>("[SWMRoot]").WorldMatrix;

                prog = p;

                ParseNodes(p.Me.CustomData);
            }

            public void Tick()
            {
                WorldMatrix = gridInteractions.GetBlockWithTag<IMyRemoteControl>("[SWMRoot]").WorldMatrix;
            }
            public void ParseNodes(string data)
            {
                MyIni p = new MyIni();
                MyIniParseResult res;
                if(!p.TryParse(data, out res))
                {
                    throw new ArgumentException();
                }

                List<string> sections = new List<string>();
                p.GetSections(sections);

                foreach(string section_name in sections)
                    if(section_name.Split(' ')[0] == "Node")
                        ParseNode(section_name, p);


                string[] hDockIDs = p.Get("Config", "HangarDocks").ToString().Split(',');
                string[] dockIDs = p.Get("Config", "DockNodes").ToString().Split(',');


                foreach (string hDockID in hDockIDs)
                    HangarDocks.Add(int.Parse(hDockID));

                foreach (string dockID in dockIDs)
                    Docks.Add(int.Parse(dockID));

                HangarEntrance = p.Get("Config", "HangarEntrance").ToInt32();
                Jobsite = p.Get("Config", "jobsite").ToInt32();
            }

            void ParseNode(string nodeSection, MyIni ini)
            {
                Vector3 Position = ini.Get(nodeSection, "Position").ToString().ToVector();

                Vector3 Forward = ini.Get(nodeSection, "Forward").ToString().ToVector();

                string[] reachableNodesStr = ini.Get(nodeSection, "ReachableNodeIDs").ToString().Split(',');

                List<int> ReachableNodes = new List<int>();

                foreach(string nodeId in reachableNodesStr)
                {
                    int id;
                    if (int.TryParse(nodeId, out id))
                        ReachableNodes.Add(id);
                }

                int ID = int.Parse(ini.Get(nodeSection, "NodeID").ToString());
                int pID = int.Parse(ini.Get(nodeSection, "ParentNodeID").ToString());

                PathNode node = new PathNode(Position, Forward, ID, pID, ReachableNodes, ini.Get(nodeSection, "AirlockTag").ToString());

                node.Invert = (ini.Get(nodeSection, "Invert").ToString() != "") ? ini.Get(nodeSection, "Invert").ToBoolean() : false;

                Nodes.Add(node);
            }

            public PathNode GetNode(int id)
            {
                foreach (PathNode node in Nodes)
                {
                    if (node.ID == id)
                        return node;
                }

                return null;
            }

            public Vector3 GetNodeWorldPosition(int nodeID)
            {
                return Vector3.Transform(GetNode(nodeID).Position, WorldMatrix);
            }

            public Vector3 GetWorldPosition(Vector3 vector)
            {
                return Vector3.Transform(vector, WorldMatrix);
            }

            public Vector3 GetLocalPosition(Vector3 worldPos)
            {
                Vector3 localPos = WorldMatrix.Translation;
                Vector3 diff = worldPos - localPos;

                return Vector3.TransformNormal(diff, MatrixD.Transpose(WorldMatrix));
            }

            public Vector3 LocalDirToWorld(Vector3 dir)
            {
                return Vector3D.TransformNormal((Vector3D)dir, (Matrix)WorldMatrix);
            }

            public Vector3 GetSystemPosition()
            {
                return WorldMatrix.Translation;
            }

            public bool IsNodeChildrenOf(int childrenID, PathNode node)
            {
                if (node.ID == childrenID)
                    return true;

                bool found = false;
                foreach(int id in node.Children)
                {
                    if (id == childrenID)
                        return true;
                    found = found || IsNodeChildrenOf(childrenID, GetNode(id));
                }

                return found;
            }

            public List<int> FindPathTo(PathNode start, PathNode end)
            {
                List<int> ans = new List<int>();
                ans.Add(start.ID);

                if(start.ID == end.ID)
                {
                    return ans;
                }
                if (IsNodeChildrenOf(end.ID, start))
                {
                    foreach (int id in start.Children)
                    {
                        if (IsNodeChildrenOf(end.ID, GetNode(id)))
                        {
                            if (end.ID == id)
                            {
                                ans.Add(id);
                                return ans;
                            }
                            else
                                return ans.Concat(FindPathTo(GetNode(id), end)).ToList();
                        }
                    }
                }
                else if (start.ParentID != -999)
                {
                    return ans.Concat(FindPathTo(GetNode(start.ParentID), end)).ToList();
                }
                return null;
            }

            public int GetEmptyHangarDock(Miner miner)
            {
                bool dockEmpty;
                foreach (int dock in HangarDocks)
                {
                    dockEmpty = true;
                    foreach (Miner m in prog.controller.Miners)
                    {
                        if (m.CurrentWaypointID == dock && m.ID != miner.ID)
                        {
                            dockEmpty = false;
                            break;
                        }
                    }
                    if (dockEmpty)
                    {
                        return dock;
                    }
                }

                return 0;
            }

            public int GetEmptyDock(Miner miner)
            {
                bool dockEmpty;
                foreach (int dock in Docks)
                {
                    dockEmpty = true;
                    foreach (Miner m in prog.controller.Miners)
                    {
                        if (m.CurrentWaypointID == dock && m.ID != miner.ID)
                        {
                            dockEmpty = false;
                            break;
                        }
                    }
                    if (dockEmpty)
                    {
                        return dock;
                    }
                }

                return 0;
            }
        }
    }
}
