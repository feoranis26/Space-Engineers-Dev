﻿using Sandbox.Game.EntityComponents;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using VRage;
using VRage.Collections;
using VRage.Game;
using VRage.Game.Components;
using VRage.Game.GUI.TextPanel;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ModAPI.Ingame.Utilities;
using VRage.Game.ObjectBuilders.Definitions;
using VRageMath;

namespace IngameScript
{
    partial class Program
    {
        public class MinerComms
        {
            IMyIntergridCommunicationSystem IGC;
            IMyBroadcastListener BListener;
            IMyUnicastListener Listener;

            const string IGC_TAG = "SwarmMiner";

            public string SystemName = "Swarm Miner";

            SwarmController controller;

            public List<long> ConnectingIDs = new List<long>();

            public Program program;

            public Heartbeat hb = new Heartbeat();

            public void Init(Program prog, IMyIntergridCommunicationSystem igc, SwarmController ctl)
            {
                IGC = igc;
                BListener = IGC.RegisterBroadcastListener(IGC_TAG);
                Listener = IGC.UnicastListener;
                controller = ctl;

                program = prog;

                hb.InitHost(program, IGC);
            }

            public void Tick(UpdateType update)
            {
                if ((update & UpdateType.Update10) > 0)
                {
                    hb.Tick();

                    foreach (Miner miner in controller.Miners)
                    {
                        if (!hb.IsConnected(miner.EntityId))
                        {
                            Disconnect(miner);
                        }
                        if(miner.State != MinerState.NotConnected)
                            UpdateMinerInfo(miner);
                    }
                }


                ProcessIncoming();
            }

            void ProcessIncoming()
            {
                while (BListener.HasPendingMessage)
                {
                    MyIGCMessage message = BListener.AcceptMessage();
                    ProcessMessage(message);
                }

                while (Listener.HasPendingMessage)
                {
                    MyIGCMessage message = Listener.AcceptMessage();
                    ProcessMessage(message);
                }
            }

            void ProcessMessage(MyIGCMessage message)
            {
                if (message.Tag == IGC_TAG && message.Data is string)
                {
                    string msg = (string)message.Data;
                    long id = message.Source;

                    program.Echo("Message from " + id + " : " + msg);

                    string[] split = msg.Split(';');

                    switch (split[0]) {
                        case "Connection":
                            ProcessConnectionRequests(split[1], id);
                            break;
                    }

                    if (!hb.IsConnected(message.Source) || controller.GetByEntityId(id) == null)
                        return;

                    switch (split[0])
                    {
                        case "Telemetry":
                            ProcessTelemetryFeedback(split[1], id);
                            break;
                    }
                }
                hb.ProcessMessage(message);
            }

            void ProcessConnectionRequests(string msg, long id)
            {
                if (msg == "RequestForAvailableHosts")
                    PingIfAvailable(id);

                if (msg == "MinerConnectionRequest")
                    ConnectMiner(id);

                if (msg == "ConfirmConnection")
                {
                    ConnectionConfirmed(id);
                }
            }

            void ProcessTelemetryFeedback(string msg, long id)
            {
                string[] split = msg.Split('/');
                switch (split[0])
                {
                    case "IsBusy":
                        controller.GetByEntityId(id).busy = bool.Parse(split[1]);
                        break;
                        
                    case "CurrentWaypoint":
                        controller.GetByEntityId(id).CurrentWaypointID = int.Parse(split[1]);
                        break;

                    case "State":
                        controller.GetByEntityId(id).State = (MinerState)int.Parse(split[1]);
                        break;
                    case "PosState":
                        controller.GetByEntityId(id).PositionState = (MinerPositionState)int.Parse(split[1]);
                        break;
                    case "FuelState":
                        controller.GetByEntityId(id).FuelState = (MinerFuelState)int.Parse(split[1]);
                        break;
                    case "ActivityState":
                        controller.GetByEntityId(id).ActivityState = (MinerActivityState)int.Parse(split[1]);
                        break;
                    case "MotionState":
                        controller.GetByEntityId(id).MotionState = (MinerMotionState)int.Parse(split[1]);
                        break;

                    case "Ready":
                        controller.NextCommand(controller.GetByEntityId(id));
                        break;
                }
            }
            void PingIfAvailable(long id)
            {
                IGC.SendUnicastMessage(id, IGC_TAG, "Connection;HostAvailable");
            }

            void ConnectMiner(long id)
            {
                if (hb.IsConnected(id))
                    return;

                program.Echo("Connecting miner :" + id);
                IGC.SendUnicastMessage(id, IGC_TAG , "Connection;RequestConfirm");
                ConnectingIDs.Add(id);
            }

            void ConnectionConfirmed(long id)
            {
                if (ConnectingIDs.Count == 0 || !ConnectingIDs.Contains(id))
                    return;

                if (hb.IsConnected(id))
                    return;
                hb.AddClient(id);
                foreach (Miner m in controller.Miners)
                {
                    if(m.EntityId == id)
                    {
                        controller.ReconnectExistingMiner(m);
                        IGC.SendUnicastMessage(id, IGC_TAG, "Connection;ConnectionSuccessful");
                        return;
                    }
                }


                IGC.SendUnicastMessage(id, IGC_TAG, "Connection;ConnectionSuccessful");
                Miner miner = new Miner(controller.Miners.Count, id);
                controller.AddMiner(miner);
                //controller.MoveMinerToWaypoint(miner, 0);

                ConnectingIDs.Remove(id);
            }


            public void SendToMiner(Miner miner, string message)
            {
                IGC.SendUnicastMessage(miner.EntityId, IGC_TAG, message);
            }

            public void Disconnect(Miner miner)
            {
                ConnectingIDs.Remove(miner.EntityId);
                controller.MinerDisconnected(miner);
            }


            public void UpdateMinerInfo(Miner miner)
            {
                string info = "SystemInfo;";

                info += program.nav.WorldMatrix.EncodeString() + "/";
                info += program.nav.Jobsite;

                SendToMiner(miner, info);
                SendToMiner(miner, "Telemetry");
            }
        }
    }
}
