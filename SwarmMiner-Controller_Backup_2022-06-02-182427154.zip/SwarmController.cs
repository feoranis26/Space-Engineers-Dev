﻿using Sandbox.Game.EntityComponents;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using VRage;
using VRage.Collections;
using VRage.Game;
using VRage.Game.Components;
using VRage.Game.GUI.TextPanel;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ModAPI.Ingame.Utilities;
using VRage.Game.ObjectBuilders.Definitions;
using VRageMath;

namespace IngameScript
{
    partial class Program
    {
        public class SwarmController
        {
            //TODO SwarmController and Comms utility classes for use in other projects


            public List<Miner> Miners = new List<Miner>();

            public MinerComms comms;
            public Navigation nav;
            public Program prog;

            public bool AreAllMinersKnown = false;

            Dictionary<int, IMyProgrammableBlock> DockControllers = new Dictionary<int, IMyProgrammableBlock>();

            public void Init(MinerComms c, Navigation n, Program p)
            {
                comms = c;
                nav = n;
                prog = p;

                MyIni parser = new MyIni();
                MyIniParseResult res;
                if (!parser.TryParse(p.Me.CustomData, out res))
                {
                    throw new ArgumentException();
                }


                foreach(int id in nav.Docks)
                {
                    IMyProgrammableBlock PB = p.gridInteractions.GetBlockWithTag<IMyProgrammableBlock>("[SWM Dock " + id + "]");
                    DockControllers.Add(id, PB);
                }
            }

            public void Tick(UpdateType update)
            {
                prog.Echo(IsSafeToMove().ToString());
                if((update & UpdateType.Update10) > 0)
                {
                    UpdateMiners();
                }
            }

            public void UpdateMiners()
            {
                if (!CheckForUnknownMiners())
                    return;

                foreach (Miner miner in Miners)
                {
                    if (miner.busy || miner.CommandQueue.Count > 0 || miner.State == MinerState.NotConnected)
                        continue;
                    MoveMiner(miner);
                }

                /*
                switch (Job.State) {
                    case SystemState.MinersEnteringHangar:
                        SendMinersToHangar();
                        break;
                    case SystemState.MinersExitingHangar:
                        SendMinersToJobsite();
                        break;
                }*/

                if (IsSafeToMove())
                {
                    foreach (Miner miner in Miners)
                    {
                        if (!IsSafeToMove())
                            break;
                        UpdateMiner(miner);
                    }
                }
            }

            public void UpdateMiner(Miner miner)
            {
                switch (miner.State)
                {
                    case MinerState.Stopped:
                        MoveMinerToHangar(miner);
                        break;

                    case MinerState.Ready:
                        MoveMinerToJobsite(miner);
                        break;

                    case MinerState.Refueling:
                        MoveMinerToDock(miner);
                        break;

                    case MinerState.Active:
                        Mine(miner);
                        break;
                }
            }

            public bool CheckForUnknownMiners()
            {
                AreAllMinersKnown = false;
                foreach(Miner miner in Miners)
                {
                    if (miner.State == MinerState.Unknown || miner.State == MinerState.NotConnected)
                        return false;
                }
                AreAllMinersKnown = true;
                return true;
            }

            List<Miner> HangarExitOrderedMiners = new List<Miner>();

            void MoveMinerToHangar(Miner miner)
            {
                int dockID = nav.GetEmptyHangarDock(miner);

                if(dockID != 0)
                {
                    if (miner.CurrentWaypointID != dockID)
                    {
                        MoveMinerToWaypoint(miner, dockID);
                    }
                }
            }

            void MoveMinerToDock(Miner miner)
            {
                int dockID = nav.GetEmptyDock(miner);

                if (dockID != 0)
                {
                    if (miner.CurrentWaypointID != dockID && miner.TargetWaypointID != dockID)
                    {
                        MoveMinerToWaypoint(miner, dockID);
                        DockControllers[dockID].TryRun("%reserve");
                    }
                    else
                    {
                        if(miner.FuelState == MinerFuelState.InventoryFull)
                            DockControllers[dockID].TryRun("%start_collection");
                        else
                            DockControllers[dockID].TryRun("%stop_collection");
                    }
                }
            }

            void MoveMinerToJobsite(Miner miner)
            {
                if (miner.CommandQueue.Count > 0 || miner.busy)
                    return;

                if (miner.CurrentWaypointID != nav.Jobsite)
                {
                    SetState(miner, MinerMotionState.MovingToJobsite2);
                    MoveMinerToWaypoint(miner, nav.Jobsite);
                }
                else if(miner.MotionState == MinerMotionState.MovingToJobsite)
                {
                    MoveMinerToHole(miner);
                    SetState(miner, MinerPositionState.AtJobsite);
                }
                else if(miner.PositionState != MinerPositionState.AtJobsite)
                {
                    SetState(miner, MinerMotionState.MovingToJobsite);
                    MoveMinerToHoleNavPos(miner);
                }
            }

            void Mine(Miner miner)
            {
                if (miner.CommandQueue.Count > 0 || miner.busy)
                    return;

                MineHole(miner, Job.Size.Z);

                if (miner.MotionState == MinerMotionState.MovingToNextHole)
                {
                    miner.HoleNum.X++;
                    if (miner.HoleNum.X >= Job.Size.X)
                    {
                        miner.HoleNum.X = 0;
                        miner.HoleNum.Y++;
                    }
                    if (miner.HoleNum.Y >= Job.Size.Y)
                    {
                        SetState(miner, MinerState.JobDone);
                        miner.HoleNum = Vector2I.Zero;
                        MoveMinerToHole(miner);
                        return;
                    }
                    MoveMinerToHole(miner);
                    SetState(miner, MinerMotionState.MovingToHole);
                }
            }

            void MoveMinerToHole(Miner miner)
            {
                Vector3 holePos = HolePos(miner);
                MoveMiner(miner, holePos, Vector3.Forward, Vector3.Up);
            }
            void MoveMinerToHoleNavPos(Miner miner)
            {
                Vector3 holePos = HolePos(miner);
                MoveMiner(miner, holePos + new Vector3(0, 0, 15), Vector3.Forward, Vector3.Up);
            }


            Vector3 HolePos(Miner miner)
            {
                float Width;
                float x;
                if (Miners.Count > 1)
                {
                    Width = Job.Size.X * Job.HoleSize.X * Miners.Count + ((Miners.Count - 1) * Job.DistBetweenMiners);
                    x = (-Width / 2) + (Job.Size.X * Job.HoleSize.X) * miner.ID + (miner.ID * Job.DistBetweenMiners);
                    x += x > 0 ? Job.DistInMiddle : -Job.DistInMiddle;
                }
                else 
                {
                    Width = Job.Size.X * Job.HoleSize.X;
                    x = -(Width / 2);
                }
                Vector3 RootPos = nav.GetNode(nav.Jobsite).Position + new Vector3(x, (Job.Size.Y / 2) * Job.HoleSize.Y, 0);
                return RootPos +  new Vector3(Job.HoleSize.X * miner.HoleNum.X, Job.HoleSize.Y * -miner.HoleNum.Y, 0);
            }
            void MineHole(Miner miner, float length)
            {

                string msg = "Mine:";
                msg += length.ToString() + "+";
                msg += nav.GetWorldPosition(HolePos(miner)).EncodeString() + "/";
                msg += Vector3.Normalize(nav.LocalDirToWorld(nav.GetNode(nav.Jobsite).Forward)).EncodeString() + "/";
                msg += "false/";
                msg += nav.Jobsite;
                SendCommand(miner, msg);
            }

            public Miner GetById(long id)
            {
                foreach (Miner m in Miners)
                {
                    if (m.ID == id)
                    {
                        return m;
                    }
                }
                return null;
            }

            public Miner GetByEntityId(long id)
            {
                foreach (Miner m in Miners)
                {
                    if (m.EntityId == id)
                    {
                        return m;
                    }
                }
                return null;
            }

            public void AddMiner(Miner miner)
            {
                Miners.Add(miner);
            }
            public void ReconnectExistingMiner(Miner miner)
            {
                 miner.State = MinerState.Unknown;
            }


            public void MinerDisconnected(Miner miner)
            {
                miner.State = MinerState.NotConnected;
            }

            public int ConnectedMiners { get
                {
                    int amount = 0;
                    foreach(Miner miner in Miners)
                    {
                        if(miner.State != MinerState.NotConnected)
                        {
                            amount++;
                        }
                    }
                    return amount;
                } 
            }

            public int BusyMiners
            {
                get
                {
                    int amount = 0;
                    foreach (Miner miner in Miners)
                    {
                        if (miner.busy)
                        {
                            amount++;
                        }
                    }
                    return amount;
                }
            }

            public void ProcessCommands(Miner miner)
            {
                if (!miner.busy && miner.CommandQueue.Count > 0)
                {
                    comms.SendToMiner(miner, "Command;" + miner.CommandQueue[0]);
                    miner.CommandQueue.RemoveAt(0);
                    miner.busy = true;
                }
            }

            public void NextCommand(Miner miner)
            {
                if (miner.CommandQueue.Count > 0)
                {
                    comms.SendToMiner(miner, "Command;" + miner.CommandQueue[0]);
                    miner.CommandQueue.RemoveAt(0);
                    miner.busy = true;
                }
            }

            public void QueueCommand(Miner miner, string command)
            {
                miner.CommandQueue.Add(command);
            }

            public void SendCommand(Miner miner, string cmd)
            {
                comms.SendToMiner(miner, "Command;" + cmd);
            }

            public void MoveMinerDirectlyToWaypoint(Miner miner, int waypointID)
            {
                string msg;

                if (nav.GetNode(miner.CurrentWaypointID).Invert != nav.GetNode(waypointID).Invert)
                {
                    msg = "Goto:";
                    msg += nav.GetNodeWorldPosition(miner.CurrentWaypointID).EncodeString() + "/";
                    msg += Vector3.Normalize(nav.LocalDirToWorld(nav.GetNode(miner.CurrentWaypointID).Forward)).EncodeString() + "/";
                    msg += Vector3.Normalize(nav.LocalDirToWorld(Vector3.Right)).EncodeString() + "/";
                    msg += miner.CurrentWaypointID;
                    QueueCommand(miner, msg);
                }
                msg = "Goto:";
                msg += nav.GetNodeWorldPosition(waypointID).EncodeString() + "/";
                msg += Vector3.Normalize(nav.LocalDirToWorld(nav.GetNode(waypointID).Forward)).EncodeString() + "/";
                msg += Vector3.Normalize(nav.LocalDirToWorld(nav.GetNode(waypointID).Invert ? Vector3.Down : Vector3.Up)).EncodeString() + "/";
                msg += waypointID;

                QueueCommand(miner, msg);
            }

            public void MoveMiner(Miner miner, Vector3 Pos, Vector3 Forward, Vector3 Up)
            {
                string msg = "Goto:";
                msg += nav.GetWorldPosition(Pos).EncodeString() + "/";
                msg += Vector3.Normalize(nav.LocalDirToWorld(Forward)).EncodeString() + "/";
                msg += Vector3.Normalize(nav.LocalDirToWorld(Up)).EncodeString() + "/";
                msg += miner.CurrentWaypointID;

                QueueCommand(miner, msg);
            }
            public bool MoveMinerToWaypoint(Miner miner, int waypointID)
            {
                if (miner.State == MinerState.Unknown)
                    return false;

                if (!IsSafeToMove())
                    return false;

                miner.TargetWaypointID = waypointID;
                return true;
            }

            public void MoveMiner(Miner miner)
            {
                if(miner.TargetWaypointID != -999 && miner.CurrentWaypointID != miner.TargetWaypointID)
                {
                    List<int> path = nav.FindPathTo(nav.GetNode(miner.CurrentWaypointID), nav.GetNode(miner.TargetWaypointID));

                    if(nav.GetNode(path[1]).AirlockPBName != "")
                    {
                        IMyProgrammableBlock airlock = prog.gridInteractions.GetBlockWithTag<IMyProgrammableBlock>(nav.GetNode(path[1]).AirlockPBName);
                        if (nav.IsNodeChildrenOf(path[1], nav.GetNode(miner.CurrentWaypointID)))
                        {
                            if (!airlock.CustomData.Contains("LockedOut"))
                            {
                                airlock.TryRun("%egress");
                                return;
                            }
                        }
                        else
                        {
                            if (!airlock.CustomData.Contains("LockedIn"))
                            {
                                airlock.TryRun("%ingress");
                                return;
                            }
                        }
                    }

                    if (nav.GetNode(miner.CurrentWaypointID).AirlockPBName != "")
                    {
                        IMyProgrammableBlock airlock = prog.gridInteractions.GetBlockWithTag<IMyProgrammableBlock>(nav.GetNode(miner.CurrentWaypointID).AirlockPBName);
                        if (nav.IsNodeChildrenOf(path[1], nav.GetNode(miner.CurrentWaypointID)))
                        {
                            if (!airlock.CustomData.Contains("LockedIn"))
                            {
                                airlock.TryRun("%ingress");
                                return;
                            }
                        }
                        else
                        {
                            if (!airlock.CustomData.Contains("LockedOut"))
                            {
                                airlock.TryRun("%egress");
                                return;
                            }
                        }
                    }

                    MoveMinerDirectlyToWaypoint(miner, path[0]);
                    MoveMinerDirectlyToWaypoint(miner, path[1]);
                }
            }

            public void SetState(Miner miner, MinerState state)
            {
                string msg = "Command;SetState:";

                msg += (int)state;

                comms.SendToMiner(miner, msg);
            }

            public void SetState(Miner miner, MinerPositionState state)
            {
                string msg = "Command;SetPosState:";

                msg += (int)state;

                comms.SendToMiner(miner, msg);
            }

            public void SetState(Miner miner, MinerFuelState state)
            {
                string msg = "Command;SetFuelState:";

                msg += (int)state;

                comms.SendToMiner(miner, msg);
            }
            public void SetState(Miner miner, MinerActivityState state)
            {
                string msg = "Command;SetActivityState:";

                msg += (int)state;

                comms.SendToMiner(miner, msg);
            }
            public void SetState(Miner miner, MinerMotionState state)
            {
                string msg = "Command;SetMotionState:";

                msg += (int)state;

                comms.SendToMiner(miner, msg);
            }

            public bool IsSafeToMove()
            {
                foreach(Miner miner in Miners)
                {
                    if (miner.TargetWaypointID != miner.CurrentWaypointID && miner.TargetWaypointID != -999)
                    {
                        return false;
                    }
                }
                return true;
            }

            public void Save()
            {
                string str = "";
                foreach (Miner miner in Miners)
                    str += miner.EncodeString() + "|";

                str += "*";

                str += ((int)Job.State).ToString();

                prog.Storage += str;
            }

            public void Load(string data)
            {
                Miners.Clear();
                string[] split = data.Split('*');

                string[] minerData = split[0].Split('|');

                foreach (string minerD in minerData)
                {
                    if (minerD == "")
                        continue;

                    Miners.Add(new Miner(minerD));
                }

                Job.State = (SystemState)int.Parse(split[1]);
            }
        }
    }
}
