﻿using Sandbox.Game.EntityComponents;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using VRage;
using VRage.Collections;
using VRage.Game;
using VRage.Game.Components;
using VRage.Game.GUI.TextPanel;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ModAPI.Ingame.Utilities;
using VRage.Game.ObjectBuilders.Definitions;
using VRageMath;

namespace IngameScript
{
    partial class Program
    {
        public class Actions
        {
            //TODO Movement path for miners when moving into holes
            //TODO Disable dampeners when docked
            //TODO Bitmask state enums
            //TODO Job size visualization

            public Program prog;
            public Motion motion;
            public Comms comms;

            public bool busy { get { return moving || mining; } }
            public bool moving = false;
            public bool mining { get { return prog.state == MinerState.Active && MineLength > 0 && (prog.posstate == MinerPositionState.InHole || prog.posstate == MinerPositionState.AtJobsite) && prog.fuelstate == MinerFuelState.OK && motionState != MinerMotionState.MovingToNextHole; } }
            public bool wasMining = false;

            public int currentWaypoint = 0;
            public int nextWaypoint = -999;


            List<IMyShipDrill> drills;
            List<IMyCargoContainer> containers;
            List<IMyGasTank> tanks;
            List<IMyBatteryBlock> batteries;
            List<IMyShipConnector> connectors;

            IMySensorBlock OreSensor;
            public MinerMotionState motionState;


            public void Init(Program p, Motion m, Comms c)
            {
                prog = p;
                motion = m;
                comms = c;

                p.gridInteractions.GetBlocks(out drills);
                p.gridInteractions.GetBlocks(out containers);
                p.gridInteractions.GetBlocks(out connectors);
                p.gridInteractions.GetBlocks(out tanks);
                p.gridInteractions.GetBlocks(out batteries);


                try
                {
                    OreSensor = p.gridInteractions.GetBlockWithTag<IMySensorBlock>("[SWM Ore Sensor]");
                }
                catch(MissingBlockException)
                {
                    p.Echo("No ore safety sensor detected. Speed limit will ALWAYS be 1 m/s when mining.");
                }

            }

            public void Tick(UpdateType update)
            {
                if (prog.state == MinerState.Unknown)
                    return;

                targetZ = Vector3.TransformNormal(mineMotionTarget - prog.orientation.rc.WorldMatrix.Translation, Matrix.Transpose(prog.orientation.rc.WorldMatrix)).Z;

                OreSensor.DetectedEntities(detected);

                if (targetZ > 0)
                    motion.SPEED_LIMIT = OreSensor == null || detected.Count >= 1 ? 1 : 5;
                else
                    motion.SPEED_LIMIT = 100;

                bool aligned = !(mineMotionTarget != Vector3.Zero && targetZ > 10) || CheckHoleAlignment();
                if (aligned) {
                    if (mining)
                        Mine();
                    else
                        Move();
                }
                
                CheckConnectors();


                if ((update & UpdateType.Update100) > 0)
                {
                    CheckDrills();
                    CheckResources();
                }

                CheckState();
            }

            public Vector3 motionTarget = Vector3.Zero;
            public Vector3 _mineTarget = Vector3.Zero;
            public Vector3 mineMotionTarget {
                get { return _mineTarget; }
                set { _mineTarget = value; CalcEndpoint();} 
            }

            public Vector3 Endpoint;

            public void CalcEndpoint()
            {
                Vector3 diff = mineMotionTarget - prog.systemInfo.SystemWorldMatrix.Translation;
                Vector3 bodyPos = Vector3.TransformNormal(diff, Matrix.Transpose(prog.systemInfo.SystemWorldMatrix));
                Vector3 tgtPosBody = bodyPos + new Vector3(0, 0, -MineLength - 5);
                Endpoint = Vector3.TransformNormal(tgtPosBody, prog.systemInfo.SystemWorldMatrix) + prog.systemInfo.SystemWorldMatrix.Translation;
            }

            public Quaternion endRotation = Quaternion.Zero;
            public Quaternion mineRotation = Quaternion.Zero;

            bool done = false;

            public void MoveTo(Vector3 target)
            {
                motionTarget = target;
                endRotation = Quaternion.Zero;
                moving = true;
            }
            public void MoveTo(Vector3 target, Quaternion endr)
            {
                motionTarget = target;
                endRotation = endr;

                moving = true;
            }
            float rD, rR;
            void Move()
            {
                moving = true;
                if (endRotation != Quaternion.Zero && motionTarget != Vector3.Zero)
                {
                    if (mineMotionTarget != Vector3.Zero && targetZ > 1)
                    {
                        motion.MoveTo(mineMotionTarget);
                    }
                    else
                    {
                        rR = motion.RotateTo(endRotation);
                        if (rR < 0.04)
                            rD = motion.MoveTo(motionTarget);

                        if (rD < 3 && rR < 0.04)
                        {
                            moving = false;
                            currentWaypoint = nextWaypoint;
                        }
                    }
                    
                }
                else if (motionTarget != Vector3.Zero && motion.MoveTo(motionTarget) < 3) 
                {
                    motion.EnableManualControl();
                    throw new Exception();
                }
                else
                {
                    moving = false;
                }

                prog.Echo("Moving: " + moving);
            }

            const float MineSpeed = 1.3f;
            public float MineLength = 0;

            float targetZ;

            List<MyDetectedEntityInfo> detected = new List<MyDetectedEntityInfo>();

            Vector3 XYDiff = new Vector3();
            Vector3 LocalMinepos = new Vector3();
            Vector3 LocalHoleAlignedTarget = new Vector3();
            Vector3 HoleAlignedTarget = new Vector3();

            bool CheckHoleAlignment()
            {
                LocalMinepos = Vector3.TransformNormal(mineMotionTarget - motion.rc.WorldMatrix.Translation, Matrix.Transpose(motion.rc.WorldMatrix));
                LocalHoleAlignedTarget = new Vector3(LocalMinepos.X, LocalMinepos.Y, 0);
                HoleAlignedTarget = Vector3.Transform(LocalHoleAlignedTarget, motion.rc.WorldMatrix);

                prog.Echo("XYDiff: " + LocalHoleAlignedTarget.EncodeString());
                prog.Echo("Diff: " + HoleAlignedTarget.EncodeString());
                prog.Echo("Pos: " + ((Vector3)motion.rc.WorldMatrix.Translation).EncodeString());


                if (LocalHoleAlignedTarget.Length() > 1)
                {
                    motion.RotateTo(Quaternion.CreateFromForwardUp(Vector3.TransformNormal(Vector3.Forward, prog.systemInfo.SystemWorldMatrix), Vector3.TransformNormal(Vector3.Up, prog.systemInfo.SystemWorldMatrix)));
                    motion.MoveTo(HoleAlignedTarget);
                    return false;
                }
                return true;
            }
            void Mine()
            {
                if (motionState == MinerMotionState.Mining)
                {
                    motion.RotateTo(Quaternion.CreateFromForwardUp(Vector3.TransformNormal(Vector3.Forward, prog.systemInfo.SystemWorldMatrix), Vector3.TransformNormal(Vector3.Up, prog.systemInfo.SystemWorldMatrix)));
                    motion.MoveTo(Endpoint);
                }
                else if(motionState == MinerMotionState.ComingOutOfHole || motionState == MinerMotionState.MovingToHole)
                {
                    motion.RotateTo(Quaternion.CreateFromForwardUp(Vector3.TransformNormal(Vector3.Forward, prog.systemInfo.SystemWorldMatrix), Vector3.TransformNormal(Vector3.Up, prog.systemInfo.SystemWorldMatrix)));
                    float distance = motion.MoveTo(mineMotionTarget);
                    prog.Echo(mineMotionTarget.EncodeString());
                    prog.Echo(distance.ToString());

                    if (distance <= 1) {
                        if (motionState == MinerMotionState.ComingOutOfHole)
                            motionState = MinerMotionState.MovingToNextHole;
                        else
                            motionState = MinerMotionState.Mining;
                    }
                }


                

                if(OreSensor == null)
                    prog.Echo("No ore safety sensor detected. Speed limit will ALWAYS be 1 m/s when mining.");

                if (motionState == MinerMotionState.MovingToHole && targetZ < MineLength)
                    motionState = MinerMotionState.Mining;

                if (targetZ > 1)
                    prog.posstate = MinerPositionState.InHole;

                if(targetZ > MineLength && motionState == MinerMotionState.Mining)
                {
                    motion.EnableManualControl();
                    motionState = MinerMotionState.ComingOutOfHole;
                }
            }

            void CheckDrills()
            {
                if(mining && prog.posstate == MinerPositionState.InHole && motionState == MinerMotionState.Mining)
                {
                    foreach(IMyShipDrill drill in drills)
                        drill.Enabled = true;
                }
                else
                {
                    foreach (IMyShipDrill drill in drills)
                        drill.Enabled = false;
                }
            }

            void CheckConnectors()
            {
                if((prog.state == MinerState.Refueling || prog.state == MinerState.Stopped) && !moving)
                {
                    foreach(IMyShipConnector connector in connectors)
                    {
                        connector.Enabled = true;
                        connector.Connect();
                    }
                }
                else
                {
                    foreach (IMyShipConnector connector in connectors)
                    {
                        connector.Enabled = false;
                        connector.Disconnect();
                    }
                }

                foreach (IMyShipConnector connector in connectors)
                {
                    if(connector.Status == MyShipConnectorStatus.Connected)
                    {
                        motion.EnableManualControl();
                        break;
                    }
                }
            }

            void CheckResources()
            {
                if(prog.fuelstate == MinerFuelState.NoH2 && connectors[0].Status == MyShipConnectorStatus.Connected)
                {
                    foreach (IMyGasTank tank in tanks)
                        tank.Stockpile = true; //Turn stonkpile on
                }
                else
                {
                    foreach (IMyGasTank tank in tanks)
                        tank.Stockpile = false;
                }
                bool areAllInventoriesFull = true;
                bool allInventoriesEmpty = true;
                foreach (IMyCargoContainer container in containers)
                {
                    if (container.GetInventory().CurrentVolume < container.GetInventory().MaxVolume - 1)
                        areAllInventoriesFull = false;

                    if (container.GetInventory().CurrentVolume > 1)
                        allInventoriesEmpty = false;
                }

                bool batteriesEmpty = true;
                bool batteriesFull = true;
                foreach (IMyBatteryBlock battery in batteries)
                {
                    if (battery.CurrentStoredPower < battery.MaxStoredPower - 0.5)
                        batteriesFull = false;

                    if (battery.CurrentStoredPower > 0.5)
                        batteriesEmpty = false;
                }

                bool tanksEmpty = true;
                bool tanksFull = true;
                foreach (IMyGasTank tank in tanks)
                {
                    if (tank.FilledRatio < 0.9)
                        tanksFull = false;

                    if (tank.FilledRatio > 0.3)
                        tanksEmpty = false;
                }


                if (areAllInventoriesFull)
                {
                    prog.fuelstate = MinerFuelState.InventoryFull;
                    
                }
                if (allInventoriesEmpty && prog.fuelstate == MinerFuelState.InventoryFull)
                {
                    prog.fuelstate = MinerFuelState.OK;
                }

                if (batteriesEmpty)
                {
                    //prog.fuelstate = MinerFuelState.NoEnergy;

                }
                if (batteriesFull && prog.fuelstate == MinerFuelState.NoEnergy)
                {
                    prog.fuelstate = MinerFuelState.OK;
                }

                if (tanksEmpty)
                {
                    prog.fuelstate = MinerFuelState.NoH2;
                }
                if (tanksFull && prog.fuelstate == MinerFuelState.NoH2)
                {
                    prog.fuelstate = MinerFuelState.OK;
                }

                if (prog.fuelstate != MinerFuelState.OK)
                {
                    if (prog.state == MinerState.Refueling)
                        return;

                    if (mining && prog.posstate == MinerPositionState.InHole)
                    {
                        motionState = MinerMotionState.MovingToHole;
                    }
                    else
                        prog.state = MinerState.Refueling;
                }
                else if(prog.state == MinerState.Refueling)
                {
                    prog.state = MinerState.RefuelDone;
                }
            }
            
            void CheckState()
            {
                if(prog.state == MinerState.RefuelDone && (prog.activity == MinerActivityState.Active || prog.activity == MinerActivityState.Paused))
                {
                    motionState = MinerMotionState.MovingToHole;
                    prog.state = prog.activity == MinerActivityState.Active && currentWaypoint == prog.systemInfo.JobSite ? MinerState.Active : MinerState.Ready;
                }

                if(prog.activity == MinerActivityState.Active)
                {
                    if (prog.state == MinerState.Ready && currentWaypoint == prog.systemInfo.JobSite && prog.fuelstate == MinerFuelState.OK)
                        prog.state = MinerState.Active;
                }
                else if(prog.activity == MinerActivityState.Paused)
                {
                    if (prog.state == MinerState.Active)
                        prog.state = MinerState.Ready;
                }
                else if(prog.activity == MinerActivityState.Stopped)
                {
                    prog.state = MinerState.Stopped;
                }
            }
        }
    }
}
