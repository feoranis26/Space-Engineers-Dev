﻿using Sandbox.Game.EntityComponents;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using VRage;
using VRage.Collections;
using VRage.Game;
using VRage.Game.Components;
using VRage.Game.GUI.TextPanel;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ModAPI.Ingame.Utilities;
using VRage.Game.ObjectBuilders.Definitions;
using VRageMath;

namespace IngameScript
{
    partial class Program : MyGridProgram
    {
        //TODO Vector math utility class
        //TODO LocalCoordinateSlave LocalCoordinateMaster WoorldCoordinate structs

        //TODO Refactor

        public Motion motion = new Motion();
        public GridInteractions gridInteractions = new GridInteractions();
        public Orientation orientation = new Orientation();
        public Comms comms = new Comms();
        public Actions actions = new Actions();

        public MinerState state = MinerState.Stopped;
        public MinerPositionState posstate = MinerPositionState.Stopped;
        public MinerFuelState fuelstate = MinerFuelState.OK;
        public MinerActivityState activity = MinerActivityState.Stopped;



        public Vector3 MotionTarget = Vector3.Zero;

        public SystemInfo systemInfo = new SystemInfo(Matrix.Zero);


        List<IMyLightingBlock> Lights;

        public Program()
        {
            gridInteractions.Init(this);
            gridInteractions.Prefix = "[SWM]";

            motion.Init(this, orientation, gridInteractions);
            orientation.Init(this, gridInteractions);
            actions.Init(this, motion, comms);
            comms.Init(this, IGC, actions);

            Runtime.UpdateFrequency = UpdateFrequency.Update10 | UpdateFrequency.Update100 | UpdateFrequency.Update1;

            try
            {
                Load();
            }
            catch (Exception e)
            {
                Echo(e.ToString());
            }

            try
            {
                Lights = gridInteractions.GetBlockGroupWithTagAsList<IMyLightingBlock>("[SWM Warning Lights]");
            }
            catch(MissingBlockException) { }
        }

        public void Save()
        {
            Storage = "";
            Storage += actions.currentWaypoint + ",";
            Storage += (int)state + ",";
            Storage += (int)posstate + ",";
            Storage += (int)fuelstate + ",";
            Storage += (int)activity + ",";

        }

        public void Main(string argument, UpdateType updateSource)
        {
            if(argument != "")
            {
                string[] sep = argument.Split(';');

                if(sep[0] == "Store")
                {
                    Storage = sep[1];
                    Load();
                }
            }
            comms.Tick(updateSource);

            if (comms.connectionState != ConnectionState.Connected)
            {
                motion.EnableManualControl();
                return;
            }

            Echo("Connected to :" + comms.SystemID);
            Echo("Current Position: " + Orientation.WorldToLocal(orientation.rc.WorldMatrix.Translation, systemInfo.SystemWorldMatrix).EncodeString());

            Echo(comms.connectionState.ToString());

            Echo("State         : " + state.ToString());
            Echo("Cnction  state: " + comms.connectionState.ToString());
            Echo("Position state: " + posstate.ToString());
            Echo("Refuel   state: " + fuelstate.ToString());
            Echo("Master   state: " + activity.ToString());
            Echo("Motion   state: " + actions.motionState.ToString());


            Echo("Current WP    :" + actions.currentWaypoint.ToString());
            Echo("Next WP       :" + actions.nextWaypoint.ToString());
            Echo("Is busy       :" + actions.busy.ToString());
            Echo("Mine length   :" + actions.MineLength.ToString());


            actions.Tick(updateSource);
            UpdateLights();

        }

        void Load()
        {
            if (Storage != "")
            {
                Echo(Storage);
                string[] split = Storage.Split(',');
                actions.currentWaypoint = int.Parse(split[0]);
                state = (MinerState)int.Parse(split[1]);
                posstate = (MinerPositionState)int.Parse(split[2]);
                fuelstate = (MinerFuelState)int.Parse(split[3]);
                activity = (MinerActivityState)int.Parse(split[4]);
            }
        }

        void UpdateLights()
        {
            if (Lights == null)
                return;

            switch (comms.connectionState)
            {
                case ConnectionState.NotConnected:
                    UpdateLights(Color.Red, 0.5f);
                    return;
                case ConnectionState.Connecting:
                    UpdateLights(Color.Yellow, 0.5f);
                    return;
            }

            switch (state)
            {
                case MinerState.Active:
                    if(posstate == MinerPositionState.InHole)
                        UpdateLights(Color.Green, 0);
                    else
                        UpdateLights(Color.Green, 1);
                    break;
                case MinerState.JobDone:
                        UpdateLights(Color.Blue, 0);
                    break;
                case MinerState.Refueling:
                    UpdateLights(Color.Yellow, 1);
                    break;
                case MinerState.Ready:
                        UpdateLights(Color.Yellow, 0);
                    break;
                case MinerState.NotConnected:
                    UpdateLights(Color.Red, 1);
                    break;
                case MinerState.Stopped:
                    UpdateLights(Color.Red, 0);
                    break;
                default:
                    UpdateLights(Color.Red, 0.5f);
                    break;
            }
        }

        void UpdateLights(Color color, float blinkInterval)
        {
            foreach(IMyLightingBlock light in Lights)
            {
                light.Color = color;
                light.BlinkIntervalSeconds = blinkInterval;
                light.BlinkLength = 50f;
            }
        }
    }
}
