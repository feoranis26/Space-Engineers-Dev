﻿using Sandbox.Game.EntityComponents;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using VRage;
using VRage.Collections;
using VRage.Game;
using VRage.Game.Components;
using VRage.Game.GUI.TextPanel;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ModAPI.Ingame.Utilities;
using VRage.Game.ObjectBuilders.Definitions;
using VRageMath;

namespace IngameScript
{
    partial class Program
    {
        public class Comms
        {
            IMyIntergridCommunicationSystem IGC;
            IMyBroadcastListener BListener;
            IMyUnicastListener Listener;

            string IGC_TAG = "SwarmMiner";

            public string SystemName = "";
            public long SystemID = -1;

            public ConnectionState connectionState = ConnectionState.NotConnected;

            public Program prog;
            public Actions actions;

            Heartbeat hb = new Heartbeat();

            public void Init(Program p, IMyIntergridCommunicationSystem igc, Actions a)
            {
                IGC = igc;
                BListener = IGC.RegisterBroadcastListener(IGC_TAG);
                Listener = IGC.UnicastListener;
                prog = p;
                actions = a;
            }

            public void ProcessIncoming()
            {
                while (Listener.HasPendingMessage)
                {
                    MyIGCMessage message = Listener.AcceptMessage();
                    hb.ProcessMessage(message);


                    if (message.Tag == IGC_TAG && message.Data is string)
                    {
                        string msg = (string)message.Data;
                        long sender = message.Source;

                        //prog.Echo("Reply from " + sender + " :" + msg);

                        string[] split = msg.Split(';');

                        switch (split[0])
                        {
                            case "Connection":
                                ProcessConnectionMSG(split[1], sender);
                                break;
                            case "SystemInfo":
                                UpdateSystemInfo(split[1]);
                                break;
                            case "Command":
                                ProcessAction(split[1]);
                                break;
                            case "Telemetry":
                                SendTelemetry();
                                break;
                        }
                    }
                }
            }

            public void Tick(UpdateType update)
            {
                hb.Tick1(update);
                if(connectionState != ConnectionState.Connected && (update & UpdateType.Update100) > 0)
                    LookForConnections();

                if (connectionState == ConnectionState.Connected && (update & UpdateType.Update10) > 0)
                {
                    try
                    {
                        hb.Tick();
                    }
                    catch(HeartbeatTimeoutException)
                    {
                        Disconnect();
                    }
                }

                ProcessIncoming();
            }

            int ticksSinceConnectAttempt = 0;
            public void LookForConnections()
            {
                prog.Echo("Looking for connections...");
                SearchForHosts();

                if (!Listener.HasPendingMessage & !BListener.HasPendingMessage && SystemID == -1)
                {
                    ticksSinceConnectAttempt++;
                    if(ticksSinceConnectAttempt > 10)
                    {
                        //prog.Me.
                        Disconnect();
                    }
                }

                if (SystemID != -1 && connectionState == ConnectionState.Connecting)
                    TryConnectTo(SystemID);
            }

            public void ProcessConnectionMSG(string msg, long id)
            {
                if (msg == "HostAvailable" && connectionState != ConnectionState.Connected)
                    TryConnectTo(id);

                if (connectionState == ConnectionState.Connecting && id == SystemID)
                {
                    if (msg == "RequestConfirm")
                        ConfirmConnection(id);
                    else if (msg == "ConnectionSuccessful")
                        Connected(id);
                }
            }

            public void SearchForHosts()
            {
                IGC.SendBroadcastMessage(IGC_TAG, "Connection;RequestForAvailableHosts");
            }

            public void TryConnectTo(long id)
            {
                prog.Echo("Attempting connection to: " + id);

                SystemID = id;
                connectionState = ConnectionState.Connecting;
                IGC.SendUnicastMessage(id, IGC_TAG, "Connection;MinerConnectionRequest");
                ticksSinceConnectAttempt = 0;
            }

            public void ConfirmConnection(long id)
            {
                IGC.SendUnicastMessage(id, IGC_TAG, "Connection;ConfirmConnection");
            }

            public void Connected(long id)
            {
                SystemID = id;
                connectionState = ConnectionState.Connected;

                hb.InitClient(prog, id, IGC);
                prog.Runtime.UpdateFrequency = UpdateFrequency.Update1 | UpdateFrequency.Update10 | UpdateFrequency.Update100;
            }


            public void UpdateSystemInfo(string msg)
            {
                string[] split = msg.Split('/');

                Matrix systemWorldMatrix = split[0].ToMatrix();

                prog.systemInfo = new SystemInfo(systemWorldMatrix);

                prog.systemInfo.JobSite = int.Parse(split[1]);
            }

            public void ProcessAction(string msg)
            {
                string[] split = msg.Split(':');

                switch (split[0])
                {
                    case "Goto":
                        Goto(split[1]);
                        break;
                    case "SetState":
                        prog.state = (MinerState)int.Parse(split[1]);
                        break;
                    case "SetPosState":
                        prog.posstate = (MinerPositionState)int.Parse(split[1]);
                        break;
                    case "SetFuelState":
                        prog.fuelstate = (MinerFuelState)int.Parse(split[1]);
                        break;
                    case "SetActivityState":
                        prog.activity = (MinerActivityState)int.Parse(split[1]);
                        break;
                    case "SetMotionState":
                        actions.motionState = (MinerMotionState)int.Parse(split[1]);
                        break;
                    case "Mine":
                        string[] split2 = split[1].Split('+');
                        string[] split3 = split2[1].Split('/');

                        actions.MineLength = float.Parse(split2[0]);
                        actions.mineMotionTarget = split3[0].ToVector();
                        break;

                    case "Abort":
                        actions.MineLength = 0;
                        prog.state = MinerState.Ready;
                        break;
                }
            }

            public void SendTelemetry()
            {
                IGC.SendUnicastMessage(SystemID, IGC_TAG, "Telemetry;IsBusy/" + actions.busy);
                IGC.SendUnicastMessage(SystemID, IGC_TAG, "Telemetry;CurrentWaypoint/" + actions.currentWaypoint);
                IGC.SendUnicastMessage(SystemID, IGC_TAG, "Telemetry;State/" + (int)prog.state);
                IGC.SendUnicastMessage(SystemID, IGC_TAG, "Telemetry;PosState/" + (int)prog.posstate);
                IGC.SendUnicastMessage(SystemID, IGC_TAG, "Telemetry;ActivityState/" + (int)prog.activity);
                IGC.SendUnicastMessage(SystemID, IGC_TAG, "Telemetry;FuelState/" + (int)prog.fuelstate);
                IGC.SendUnicastMessage(SystemID, IGC_TAG, "Telemetry;MotionState/" + (int)actions.motionState);


                if (!actions.busy)
                    IGC.SendUnicastMessage(SystemID, IGC_TAG, "Telemetry;Ready");
            }

            public void Goto(string msg)
            {
                string[] split = msg.Split('/');
                Vector3 tgt = split[0].ToVector();
                Quaternion tgtRot = Quaternion.CreateFromForwardUp(Vector3.Normalize(split[1].ToVector()), Vector3.Normalize(split[2].ToVector()));

                actions.MoveTo(tgt, tgtRot);
                actions.nextWaypoint = int.Parse(split[3]);
            }

            public void RequestNextCommand()
            {
                SendTelemetry();
                //IGC.SendUnicastMessage(SystemID, IGC_TAG, "Telemetry;Ready");
            }

            void Disconnect()
            {
                connectionState = ConnectionState.NotConnected;
                prog.Runtime.UpdateFrequency = UpdateFrequency.Update10 | UpdateFrequency.Update100;
                SystemID = -1;
                hb.UninitClient();
            }
        }
    }
}
