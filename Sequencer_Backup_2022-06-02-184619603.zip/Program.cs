﻿using Sandbox.Game.EntityComponents;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using VRage;
using VRage.Collections;
using VRage.Game;
using VRage.Game.Components;
using VRage.Game.GUI.TextPanel;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ModAPI.Ingame.Utilities;
using VRage.Game.ObjectBuilders.Definitions;
using VRageMath;

namespace IngameScript
{
    partial class Program : MyGridProgram
    {
        Dictionary<string, BlockData> Blocks = new Dictionary<string, BlockData>();
        Dictionary<string, Step> Steps = new Dictionary<string, Step>();
        Dictionary<string, Action> Actions = new Dictionary<string, Action>();

        GridInteractions gridInteractions = new GridInteractions();

        IEnumerator<bool> runAction;

        public Program()
        {
            gridInteractions.Init(this);

            ParseConfig(Me.CustomData);

            Runtime.UpdateFrequency = UpdateFrequency.Update1;
        }

        public void Save()
        {

        }

        public void Main(string argument, UpdateType updateSource)
        {
            if(argument != "")
            {
                string[] split = argument.Split(' ');
                if(split[0] == "run")
                {
                    runAction = RunAction(split[1]);
                }
            }
            if(runAction != null) //An action is being executed!
            {
                if (!runAction.MoveNext())
                {
                    runAction.Dispose();
                    runAction = null;
                }
            }
        }

        public IEnumerator<bool> RunAction(string actionName)
        {
            Action action = Actions[actionName];

            if (action == null)
                throw new Exception($"No action with {actionName} found.");

            foreach (Step step in action.steps)
            {
                while (!ExecuteStep(step))
                    yield return true;
            }
            yield return false;
            
        }

        public bool ExecuteStep(Step step)
        {
            foreach(BlockAction action in step.Actions)
            {
                BlockData block = action.Block;

                if(block.Name == "")
                {
                    throw new MissingBlockException($"Error while executing \"{step.Name}\": Block with name \"{block.Name}\" not found.");
                }
                
                if(block.Type == BlockType.Piston)
                {
                    IMyPistonBase piston = (IMyPistonBase)block.Block;

                    piston.Velocity = action.Value;
                }
            }

            BlockData WaitBlock = step.Wait.Block;

            if (WaitBlock.TerminalName == "")
            {
                throw new MissingBlockException($"Error while executing \"{step.Name}\": Block with name \"{WaitBlock.TerminalName}\" not found.");
            }

            if (step.WaitForGreaterThan)
            {
                if (WaitBlock.Type == BlockType.Piston)
                    return ((IMyPistonBase)WaitBlock.Block).CurrentPosition > step.Wait.Value;
                else
                    return ((IMyMotorStator)WaitBlock.Block).Angle > step.Wait.Value;
            }
            else
            {
                if (WaitBlock.Type == BlockType.Piston)
                    return ((IMyPistonBase)WaitBlock.Block).CurrentPosition < step.Wait.Value;
                else
                    return ((IMyMotorStator)WaitBlock.Block).Angle < step.Wait.Value;
            }
        }

        #region ConfigParse
        void ParseConfig(string data)
        {
            MyIni p = new MyIni();
            MyIniParseResult res;
            if (!p.TryParse(data, out res))
            {
                throw new ArgumentException("Failed to parse!");
            }

            ParseBlocks(p);

            List<string> sections = new List<string>();
            p.GetSections(sections);

            foreach (string section_name in sections)
            {
                if (section_name.Split(' ')[0] == "Step")
                    ParseStep(section_name, p);
                else if (section_name.Split(' ')[0] == "Action")
                    ParseAction(section_name, p);
            }
        }
        void ParseBlocks(MyIni ini)
        {
            List<MyIniKey> blocks = new List<MyIniKey>();
            ini.GetKeys("Blocks", blocks);

            foreach (MyIniKey blockNameKey in blocks)
            {
                string blockName = blockNameKey.Name;
                string blockTerminalName = ini.Get("Blocks", blockName).ToString();
                Echo(blockName);

                IMyTerminalBlock block = gridInteractions.GetBlockWithTag<IMyTerminalBlock>(blockTerminalName);

                BlockData data = new BlockData(blockName, blockTerminalName, block is IMyPistonBase ? BlockType.Piston : BlockType.Rotor, block);
                Blocks.Add(blockName, data);
            }
        }
        void ParseStep(string section_name, MyIni ini)
        {
            Step step = new Step();
            step.Name = section_name.Split(' ')[1];

            List<MyIniKey> Keys = new List<MyIniKey>();
            ini.GetKeys(section_name, Keys);

            foreach(MyIniKey blockNameKey in Keys)
            {
                if(blockNameKey.Name.Split('-')[0] == "Wait")
                {
                    string[] split = blockNameKey.Name.Split('-');

                    BlockData waitBlock;
                    try
                    {
                        waitBlock = Blocks[split[1]];
                    }
                    catch(KeyNotFoundException)
                    {
                        throw new MissingBlockException($"Error while parsing \"{section_name}\": Block with name \"{split[1]}\" not found.");
                    }

                    float waitValue = ini.Get(section_name, blockNameKey.Name).ToSingle();

                    step.Wait = new BlockAction(waitBlock, waitValue);
                    continue;
                }

                if (blockNameKey.Name == "WaitType")
                    continue;

                string blockName = blockNameKey.Name;
                BlockData block;
                try
                {
                    block = Blocks[blockName];
                }
                catch(KeyNotFoundException)
                {
                    throw new MissingBlockException($"Error while parsing \"{section_name}\": Block with name \"{blockName}\" not found.");
                }

                float blockValue = ini.Get(section_name, blockNameKey.Name).ToSingle();
                step.Actions.Add(new BlockAction(block, blockValue));
            }

            if(step.Wait.Block.Name == "")
            {
                throw new Exception($"Error while parsing \"{section_name}\": No wait condition specified.");

            }

            string waitType = ini.Get(section_name, "WaitType").ToString();
            if(waitType == "")
                throw new Exception($"Error while parsing \"{section_name}\": No WaitType specified.");
            else if (waitType == "GreaterThan")
                step.WaitForGreaterThan = true;
            else if (waitType == "LessThan")
                step.WaitForGreaterThan = false;
            else
                throw new Exception($"Error while parsing \"{section_name}\": Invalid WaitType \"{waitType}\". Expected \"LessThan\" or \"GreaterThan\"");

            Steps.Add(step.Name, step);
        }
        void ParseAction(string section_name, MyIni ini)
        {
            Action action = new Action();
            action.Name = section_name.Split(' ')[1];

            string[] stepNames = ini.Get(section_name, "Steps").ToString().Split(',');

            foreach (string stepName in stepNames)
            {
                Step step;
                try
                {
                    step = Steps[stepName];
                }
                catch (KeyNotFoundException)
                {
                    throw new Exception($"Error while parsing \"{section_name}\": Step with name \"{stepName}\" not found.");
                }

                action.steps.Add(step);
            }
            Actions.Add(action.Name, action);
        }
        #endregion
        #region Data

        public struct BlockData
        {
            public string Name;
            public string TerminalName;
            public BlockType Type;
            public IMyTerminalBlock Block;

            public BlockData(string name, string terminalName, BlockType type, IMyTerminalBlock block)
            {
                Name = name;
                TerminalName = terminalName;
                Type = type;
                Block = block;
            }
        }

        public struct BlockAction
        {
            public BlockData Block;
            public float Value;
            public BlockAction(BlockData block, float value)
            {
                Block = block;
                Value = value;
            }
        }

        public enum BlockType
        {
            Piston = 0,
            Rotor = 1
        }

        public class Step
        {
            public string Name;
            public List<BlockAction> Actions = new List<BlockAction>();
            public BlockAction Wait;
            public bool WaitForGreaterThan;
        }

        public class Action
        {
            public string Name;
            public List<Step> steps = new List<Step>();
        }
        #endregion
    }
}
